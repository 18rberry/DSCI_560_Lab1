# ask the user to enter their name 
name = input("Please enter your name: ")

# greet the user 
print(f"Hello, {name}!")